namespace Dalek_Mint.Migrations
{
    using System.Data.Entity.Migrations;

    /// <summary>
    /// Defines the <see cref="endOfSprint3" />
    /// </summary>
    public partial class endOfSprint3 : DbMigration
    {
        /// <summary>
        /// The Up
        /// </summary>
        public override void Up()
        {
        }

        /// <summary>
        /// The Down
        /// </summary>
        public override void Down()
        {
        }
    }
}
