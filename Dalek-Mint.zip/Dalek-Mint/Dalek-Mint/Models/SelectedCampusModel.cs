﻿namespace Dalek_Mint.Models
{
    /// <summary>
    /// Defines the <see cref="SelectedCampusModel" />
    /// </summary>
    public class SelectedCampusModel
    {
    }
}
