﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dalek_Mint.enums
{
    public enum CategoryType
    {
        Giveaways = 1,
        Competitions = 2,
        StudentLife = 3,
        Sports = 4,
        Speaker = 5,
        Trips = 6,
        CareerService = 7

    }
}